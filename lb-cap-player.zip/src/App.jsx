import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import * as Tone from "tone";
import {
  Play, Pause, SkipBack, SkipForward, Mic, Music, ListMusic, Settings, Home,
  Heart, Search, Plus, Trash2, Edit3, ChevronUp, ChevronDown, Minus, X,
  Volume2, Repeat, FileText, Guitar, Target, Users2, Bluetooth, Upload,
  ArrowLeft, Maximize2, Minimize2, Check, AlertCircle, Gauge, ListPlus,
  BarChart3, Radio, Headphones, Zap, Star,
} from "lucide-react";

/* ============================================================
   MUSIC THEORY CORE — usado por transposição, acordes e harmonia
   ============================================================ */
const NOTES_SHARP = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
const MAJOR_SCALE_STEPS = [0, 2, 4, 5, 7, 9, 11];

function noteIndex(root, accidental) {
  let idx = NOTES_SHARP.indexOf(root);
  if (accidental === "#") idx += 1;
  if (accidental === "b") idx -= 1;
  return ((idx % 12) + 12) % 12;
}
function transposeChordToken(chord, semitones) {
  if (!chord) return chord;
  return chord
    .split("/")
    .map((part) => {
      const m = part.match(/^([A-G])(#|b)?(.*)$/);
      if (!m) return part;
      const idx = noteIndex(m[1], m[2]);
      const newIdx = ((idx + semitones) % 12 + 12) % 12;
      return NOTES_SHARP[newIdx] + m[3];
    })
    .join("/");
}
function transposeKey(key, semitones) {
  if (!key) return key;
  const m = key.match(/^([A-G])(#|b)?(.*)$/);
  if (!m) return key;
  const idx = noteIndex(m[1], m[2]);
  const newIdx = ((idx + semitones) % 12 + 12) % 12;
  return NOTES_SHARP[newIdx] + m[3];
}
function renderChordLyric(text, semitones) {
  if (!text) return null;
  const parts = text.split(/(\[[^\]]+\])/g);
  return parts.map((p, i) => {
    const m = p.match(/^\[([^\]]+)\]$/);
    if (m) return <span key={i} className="text-red-500 font-bold">{transposeChordToken(m[1], semitones)}</span>;
    return <span key={i}>{p}</span>;
  });
}
function keyScaleNotes(keyRoot) {
  const rootIdx = NOTES_SHARP.indexOf(keyRoot) || 0;
  return MAJOR_SCALE_STEPS.map((s) => (rootIdx + s) % 12);
}
function nearestScaleDegreeIndex(pc, scale) {
  let best = 0, bd = 99;
  scale.forEach((n, i) => {
    const d = Math.min(Math.abs(n - pc), 12 - Math.abs(n - pc));
    if (d < bd) { bd = d; best = i; }
  });
  return best;
}
// Retorna o deslocamento em semitons (harmonia diatônica real, baseada na escala maior do tom da música)
function diatonicInterval(noteMidi, keyRoot, steps) {
  const scale = keyScaleNotes(keyRoot || "C");
  const pc = ((noteMidi % 12) + 12) % 12;
  const degIdx = nearestScaleDegreeIndex(pc, scale);
  const targetDeg = ((degIdx + steps) % 7 + 7) % 7;
  const octaveAdj = Math.floor((degIdx + steps) / 7);
  const targetPc = scale[targetDeg];
  const diff = ((targetPc - pc) + 12) % 12;
  return diff + octaveAdj * 12;
}

/* ============================================================
   PITCH DETECTION — autocorrelação real (ACF2+), não simulada
   ============================================================ */
function autoCorrelate(buffer, sampleRate) {
  const SIZE = buffer.length;
  let rms = 0;
  for (let i = 0; i < SIZE; i++) rms += buffer[i] * buffer[i];
  rms = Math.sqrt(rms / SIZE);
  if (rms < 0.012) return { frequency: -1, clarity: 0 };

  let r1 = 0, r2 = SIZE - 1;
  const thres = 0.2;
  for (let i = 0; i < SIZE / 2; i++) { if (Math.abs(buffer[i]) < thres) { r1 = i; break; } }
  for (let i = 1; i < SIZE / 2; i++) { if (Math.abs(buffer[SIZE - i]) < thres) { r2 = SIZE - i; break; } }
  const buf2 = buffer.slice(r1, r2);
  const SIZE2 = buf2.length;
  if (SIZE2 < 8) return { frequency: -1, clarity: 0 };

  const c = new Array(SIZE2).fill(0);
  for (let i = 0; i < SIZE2; i++) {
    for (let j = 0; j < SIZE2 - i; j++) c[i] += buf2[j] * buf2[j + i];
  }
  let d = 0;
  while (d < SIZE2 - 1 && c[d] > c[d + 1]) d++;
  let maxval = -1, maxpos = -1;
  for (let i = d; i < SIZE2; i++) { if (c[i] > maxval) { maxval = c[i]; maxpos = i; } }
  let T0 = maxpos;
  if (T0 <= 0 || T0 >= SIZE2 - 1) return { frequency: -1, clarity: 0 };

  const x1 = c[T0 - 1], x2 = c[T0], x3 = c[T0 + 1];
  const a = (x1 + x3 - 2 * x2) / 2, b = (x3 - x1) / 2;
  if (a) T0 = T0 - b / (2 * a);

  const clarity = c[0] ? maxval / c[0] : 0;
  const frequency = sampleRate / T0;
  return { frequency, clarity: Math.max(0, Math.min(1, clarity)) };
}
const A4 = 440;
function freqToNote(freq) {
  if (!freq || freq <= 0) return null;
  const noteNum = 12 * Math.log2(freq / A4) + 69;
  const rounded = Math.round(noteNum);
  const cents = Math.round((noteNum - rounded) * 100);
  const name = NOTES_SHARP[((rounded % 12) + 12) % 12];
  const octave = Math.floor(rounded / 12) - 1;
  return { midi: rounded, name: `${name}${octave}`, cents, freq };
}
function nameFromMidi(midi) {
  const name = NOTES_SHARP[((Math.round(midi) % 12) + 12) % 12];
  const octave = Math.floor(Math.round(midi) / 12) - 1;
  return `${name}${octave}`;
}

/* ============================================================
   CHORD DETECTION — Pitch Class Profile (chroma) + template matching real
   ============================================================ */
const CHORD_TEMPLATES = [];
NOTES_SHARP.forEach((root, i) => {
  const maj = new Array(12).fill(0); [0, 4, 7].forEach((iv) => (maj[(i + iv) % 12] = 1));
  const min = new Array(12).fill(0); [0, 3, 7].forEach((iv) => (min[(i + iv) % 12] = 1));
  CHORD_TEMPLATES.push({ name: root, template: maj });
  CHORD_TEMPLATES.push({ name: root + "m", template: min });
});
function computeChroma(freqDb, sampleRate, fftSize) {
  const chroma = new Array(12).fill(0);
  const binHz = sampleRate / (2 * freqDb.length);
  for (let i = 1; i < freqDb.length; i++) {
    const db = freqDb[i];
    if (!isFinite(db) || db < -85) continue;
    const freq = i * binHz;
    if (freq < 70 || freq > 1800) continue;
    const mag = Math.pow(10, db / 20);
    const midi = 12 * Math.log2(freq / 440) + 69;
    const pc = ((Math.round(midi) % 12) + 12) % 12;
    chroma[pc] += mag;
  }
  const max = Math.max(...chroma, 1e-6);
  return chroma.map((v) => v / max);
}
function cosineSim(a, b) {
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < 12; i++) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; }
  if (!na || !nb) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}
function matchChord(chroma) {
  let best = null, bestScore = -1;
  for (const t of CHORD_TEMPLATES) {
    const score = cosineSim(chroma, t.template);
    if (score > bestScore) { bestScore = score; best = t; }
  }
  return { bestChord: best, confidence: bestScore };
}

/* ============================================================
   MIC LISTENER HOOK — voz + violão, um único stream de microfone
   ============================================================ */
function useVocalGuitarListener(active, mode) {
  const [note, setNote] = useState(null);
  const [noteClarity, setNoteClarity] = useState(0);
  const [chord, setChord] = useState(null);
  const [chordConfidence, setChordConfidence] = useState(0);
  const [error, setError] = useState(null);
  const refs = useRef({});

  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    (async () => {
      try {
        await Tone.start();
        const mic = new Tone.UserMedia();
        await mic.open();
        if (cancelled) { mic.close(); return; }
        const waveAnalyser = new Tone.Analyser("waveform", 2048);
        const fftAnalyser = new Tone.Analyser("fft", 4096);
        mic.connect(waveAnalyser);
        mic.connect(fftAnalyser);
        refs.current = { mic, waveAnalyser, fftAnalyser };
        const sampleRate = Tone.getContext().sampleRate;
        const loop = () => {
          if (!refs.current.mic) return;
          const timeData = waveAnalyser.getValue();
          const { frequency, clarity } = autoCorrelate(timeData, sampleRate);
          if (mode !== "guitar-ref" && frequency > 50 && frequency < 1200 && clarity > 0.9) {
            setNote(freqToNote(frequency)); setNoteClarity(clarity);
          } else if (mode !== "guitar-ref") { setNote(null); setNoteClarity(0); }

          if (mode !== "voice-only") {
            const freqData = fftAnalyser.getValue();
            const chroma = computeChroma(freqData, sampleRate, 4096);
            const { bestChord, confidence } = matchChord(chroma);
            setChordConfidence(confidence);
            setChord(confidence > 0.72 ? bestChord : null);
          }
          refs.current.raf = requestAnimationFrame(loop);
        };
        loop();
      } catch (e) {
        setError("Não foi possível acessar o microfone. Verifique as permissões do navegador/app.");
      }
    })();
    return () => {
      cancelled = true;
      cancelAnimationFrame(refs.current.raf);
      try { refs.current.mic && refs.current.mic.close(); } catch {}
      try { refs.current.waveAnalyser && refs.current.waveAnalyser.dispose(); } catch {}
      try { refs.current.fftAnalyser && refs.current.fftAnalyser.dispose(); } catch {}
      refs.current = {};
    };
  }, [active, mode]);

  return { note, noteClarity, chord, chordConfidence, error };
}

/* ============================================================
   MIDI / PEDAL — Web MIDI API real
   ============================================================ */
function useMIDIPedals(onAction, mapping, listening, onCapture) {
  const [supported, setSupported] = useState(null);
  const [deviceNames, setDeviceNames] = useState([]);
  const mappingRef = useRef(mapping);
  useEffect(() => { mappingRef.current = mapping; }, [mapping]);
  const onActionRef = useRef(onAction);
  useEffect(() => { onActionRef.current = onAction; }, [onAction]);
  const onCaptureRef = useRef(onCapture);
  useEffect(() => { onCaptureRef.current = onCapture; }, [onCapture]);
  const listeningRef = useRef(listening);
  useEffect(() => { listeningRef.current = listening; }, [listening]);

  useEffect(() => {
    if (!navigator.requestMIDIAccess) { setSupported(false); return; }
    let access;
    navigator.requestMIDIAccess().then((a) => {
      access = a;
      setSupported(true);
      setDeviceNames([...a.inputs.values()].map((i) => i.name || "Dispositivo MIDI"));
      a.inputs.forEach((input) => {
        input.onmidimessage = (msg) => {
          const key = Array.from(msg.data).join(",");
          if (listeningRef.current && onCaptureRef.current) { onCaptureRef.current(key); return; }
          const action = mappingRef.current[key];
          if (action && onActionRef.current) onActionRef.current(action);
        };
      });
    }).catch(() => setSupported(false));
    return () => { if (access) access.inputs.forEach((i) => { i.onmidimessage = null; }); };
  }, []);

  return { supported, deviceNames };
}

/* ============================================================
   STORAGE
   ============================================================ */
const K_SONGS = "lbcap:songs";
const K_SETLISTS = "lbcap:setlists";
const K_HISTORY = "lbcap:history";
const K_MIDI = "lbcap:midi_map";

async function storageGet(key, fallback) {
  try { const r = await window.storage.get(key, false); return r ? JSON.parse(r.value) : fallback; }
  catch { return fallback; }
}
async function storageSet(key, value) {
  try { await window.storage.set(key, JSON.stringify(value), false); } catch (e) { console.error(e); }
}

const GENRES = ["Sertanejo","Rock","Pop","MPB","Gospel","Country","Flashback","Voz e Violão","Personalizadas"];
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
const fmtTime = (s) => { if (!isFinite(s) || s < 0) s = 0; const m = Math.floor(s / 60), sec = Math.floor(s % 60); return `${m}:${sec.toString().padStart(2, "0")}`; };
const fmtDate = (ts) => new Date(ts).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });

/* ============================================================
   AUDIO ENGINE — playback com tom/velocidade independentes
   ============================================================ */
function useAudioEngine({ onEnded }) {
  const playerRef = useRef(null);
  const pitchRef = useRef(null);
  const clockRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [duration, setDuration] = useState(0);
  const [position, setPosition] = useState(0);
  const [speed, setSpeedState] = useState(1);
  const [semitones, setSemitonesState] = useState(0);
  const [volume, setVolumeState] = useState(0.85);
  const stateRef = useRef({ pausedAt: 0, startCtx: 0, playing: false });

  const cleanup = useCallback(() => {
    clearInterval(clockRef.current);
    if (playerRef.current) { try { playerRef.current.stop(); playerRef.current.dispose(); } catch {} }
    if (pitchRef.current) { try { pitchRef.current.dispose(); } catch {} }
    playerRef.current = null; pitchRef.current = null;
    stateRef.current = { pausedAt: 0, startCtx: 0, playing: false };
    setIsPlaying(false); setPosition(0); setDuration(0);
  }, []);

  const load = useCallback(async (url, initialSpeed = 1, initialSemitones = 0) => {
    cleanup(); setError(null); setIsLoading(true);
    try {
      await Tone.start();
      const pitch = new Tone.PitchShift({ windowSize: 0.08 }).toDestination();
      const player = new Tone.Player({ url, onerror: () => setError("Não foi possível reproduzir este arquivo.") });
      player.connect(pitch);
      await Tone.loaded();
      player.playbackRate = initialSpeed;
      pitch.pitch = initialSemitones - 12 * Math.log2(initialSpeed);
      pitch.volume.value = Tone.gainToDb(volume);
      playerRef.current = player; pitchRef.current = pitch;
      setDuration(player.buffer.duration);
      setSpeedState(initialSpeed); setSemitonesState(initialSemitones);
      setIsLoading(false);
    } catch (e) {
      console.error(e); setError("Não foi possível reproduzir este arquivo."); setIsLoading(false);
    }
  }, [cleanup, volume]);

  const tick = useCallback(() => {
    const st = stateRef.current;
    if (!st.playing || !playerRef.current) return;
    const elapsed = (Tone.now() - st.startCtx) * playerRef.current.playbackRate;
    const pos = st.pausedAt + elapsed;
    if (pos >= duration && duration > 0) { setPosition(duration); pause(true); onEnded && onEnded(); return; }
    setPosition(pos);
  }, [duration, onEnded]); // eslint-disable-line

  const play = useCallback(() => {
    if (!playerRef.current) return;
    const st = stateRef.current;
    playerRef.current.start(undefined, st.pausedAt);
    st.startCtx = Tone.now(); st.playing = true; setIsPlaying(true);
    clearInterval(clockRef.current); clockRef.current = setInterval(tick, 150);
  }, [tick]);

  const pause = useCallback(() => {
    const st = stateRef.current;
    if (!playerRef.current) return;
    if (st.playing) {
      const elapsed = (Tone.now() - st.startCtx) * playerRef.current.playbackRate;
      st.pausedAt = Math.min(st.pausedAt + elapsed, duration);
      try { playerRef.current.stop(); } catch {}
    }
    st.playing = false; clearInterval(clockRef.current); setIsPlaying(false);
  }, [duration]);

  const seek = useCallback((t) => {
    const st = stateRef.current;
    const wasPlaying = st.playing;
    if (wasPlaying && playerRef.current) { try { playerRef.current.stop(); } catch {} }
    st.pausedAt = Math.max(0, Math.min(t, duration));
    setPosition(st.pausedAt);
    if (wasPlaying) { playerRef.current.start(undefined, st.pausedAt); st.startCtx = Tone.now(); st.playing = true; }
  }, [duration]);

  const setSpeed = useCallback((rate) => {
    setSpeedState(rate);
    if (!playerRef.current) return;
    const st = stateRef.current;
    if (st.playing) {
      const elapsed = (Tone.now() - st.startCtx) * playerRef.current.playbackRate;
      st.pausedAt = Math.min(st.pausedAt + elapsed, duration);
      st.startCtx = Tone.now();
      try { playerRef.current.stop(); } catch {}
      playerRef.current.playbackRate = rate;
      playerRef.current.start(undefined, st.pausedAt);
    } else playerRef.current.playbackRate = rate;
    if (pitchRef.current) pitchRef.current.pitch = semitones - 12 * Math.log2(rate);
  }, [duration, semitones]);

  const setSemitonesFn = useCallback((semi) => {
    setSemitonesState(semi);
    if (pitchRef.current) pitchRef.current.pitch = semi - 12 * Math.log2(speed);
  }, [speed]);

  const setVolume = useCallback((v) => {
    setVolumeState(v);
    if (pitchRef.current) pitchRef.current.volume.value = Tone.gainToDb(Math.max(0.0001, v));
  }, []);

  useEffect(() => () => cleanup(), [cleanup]);

  return { load, play, pause, seek, cleanup, setSpeed, setSemitones: setSemitonesFn, setVolume,
    isPlaying, isLoading, error, duration, position, speed, semitones, volume };
}

/* ============================================================
   UI PRIMITIVES
   ============================================================ */
function BigButton({ icon: Icon, label, sub, onClick, tone = "dark", className = "" }) {
  const tones = { dark: "bg-neutral-900 text-white", red: "bg-red-600 text-white", outline: "bg-white text-neutral-900 border border-neutral-200" };
  return (
    <button onClick={onClick} className={`flex items-center gap-3 w-full rounded-2xl px-5 py-4 active:scale-[0.98] transition ${tones[tone]} ${className}`}>
      {Icon && <Icon size={24} strokeWidth={2.2} />}
      <div className="text-left flex-1">
        <div className="font-bold text-[15px] tracking-wide">{label}</div>
        {sub && <div className="text-xs opacity-70">{sub}</div>}
      </div>
    </button>
  );
}
function NavBar({ screen, setScreen, hidden }) {
  if (hidden) return null;
  const items = [
    { id: "home", icon: Home, label: "Início" },
    { id: "library", icon: Music, label: "Músicas" },
    { id: "setlists", icon: ListMusic, label: "Setlists" },
    { id: "voice", icon: Mic, label: "Voz" },
    { id: "settings", icon: Settings, label: "Config" },
  ];
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-neutral-800 flex justify-around py-2 z-40">
      {items.map((it) => {
        const active = screen === it.id;
        return (
          <button key={it.id} onClick={() => setScreen(it.id)} className="flex flex-col items-center gap-0.5 px-3 py-1">
            <it.icon size={20} className={active ? "text-red-500" : "text-neutral-500"} strokeWidth={2.3} />
            <span className={`text-[10px] font-semibold ${active ? "text-red-500" : "text-neutral-500"}`}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}
function TopBar({ title, onBack, right }) {
  return (
    <div className="flex items-center justify-between px-4 py-3 sticky top-0 bg-black/95 backdrop-blur z-30 border-b border-neutral-900">
      <div className="flex items-center gap-2 min-w-0">
        {onBack && <button onClick={onBack} className="p-1 -ml-1"><ArrowLeft size={22} className="text-white" /></button>}
        <h1 className="text-white font-bold text-lg tracking-wide truncate">{title}</h1>
      </div>
      {right}
    </div>
  );
}
function EmptyState({ icon: Icon, title, sub }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 px-6 text-neutral-500">
      <Icon size={36} className="mb-3 opacity-50" />
      <p className="font-semibold text-neutral-300">{title}</p>
      {sub && <p className="text-sm mt-1">{sub}</p>}
    </div>
  );
}
function Section({ title, children }) {
  return (
    <div className="mb-6">
      <div className="text-neutral-400 text-xs font-bold uppercase tracking-wider mb-2">{title}</div>
      <div className="space-y-2">{children}</div>
    </div>
  );
}
function SongRow({ song, onClick, onToggleFav, right }) {
  return (
    <div onClick={onClick} className={`flex items-center gap-3 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-3 ${onClick ? "active:scale-[0.98] cursor-pointer" : ""}`}>
      <div className="w-11 h-11 rounded-lg bg-neutral-800 flex items-center justify-center flex-shrink-0 overflow-hidden">
        {song.cover ? <img src={song.cover} alt="" className="w-full h-full object-cover" /> : <Music size={18} className="text-neutral-500" />}
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-white font-semibold text-sm truncate">{song.title || "Sem título"}</div>
        <div className="text-neutral-500 text-xs truncate">{song.artist || "Artista desconhecido"} • Tom {transposeKey(song.originalKey, song.semitoneOffset || 0) || "—"}</div>
      </div>
      {onToggleFav && (
        <button onClick={(e) => { e.stopPropagation(); onToggleFav(song.id); }} className="p-1">
          <Heart size={18} className={song.favorite ? "text-red-500 fill-red-500" : "text-neutral-600"} />
        </button>
      )}
      {right}
    </div>
  );
}
function ScoreBar({ score }) {
  const color = score >= 85 ? "bg-red-500" : score >= 65 ? "bg-amber-500" : "bg-neutral-600";
  return (
    <div className="w-full h-2 bg-neutral-800 rounded-full overflow-hidden">
      <div className={`h-full ${color}`} style={{ width: `${Math.max(2, score)}%` }} />
    </div>
  );
}
function PermissionNotice({ error }) {
  if (!error) return null;
  return (
    <div className="flex items-start gap-2 bg-red-950 border border-red-900 text-red-400 text-xs rounded-xl px-3 py-2.5 mb-3">
      <AlertCircle size={15} className="mt-0.5 flex-shrink-0" />
      <span>{error}</span>
    </div>
  );
}

/* ============================================================
   HOME
   ============================================================ */
function HomeScreen({ songs, setlists, onStartShow, setScreen, history, openVoiceTab }) {
  const favorites = songs.filter((s) => s.favorite).slice(0, 4);
  const recents = [...history].slice(-4).reverse();
  const lastSetlist = setlists[setlists.length - 1];
  return (
    <div className="px-4 pb-28 pt-4">
      <div className="mb-6">
        <div className="text-3xl font-black text-white tracking-tight">LB <span className="text-red-500">CAP</span> PLAYER</div>
        <div className="text-neutral-500 text-sm mt-1">Pronto para o show.</div>
      </div>
      <button onClick={onStartShow} disabled={!setlists.length}
        className="w-full rounded-2xl bg-red-600 disabled:bg-neutral-800 disabled:text-neutral-600 text-white py-6 flex flex-col items-center justify-center gap-1 mb-6 active:scale-[0.98] transition shadow-lg shadow-red-900/20">
        <Play size={30} fill="currentColor" />
        <span className="font-black text-lg tracking-wide">INICIAR SHOW</span>
        {!setlists.length && <span className="text-xs font-normal">crie um setlist para começar</span>}
      </button>
      <div className="grid grid-cols-2 gap-3 mb-6">
        <BigButton icon={Music} label="Minhas Músicas" onClick={() => setScreen("library")} tone="outline" />
        <BigButton icon={ListMusic} label="Meus Setlists" onClick={() => setScreen("setlists")} tone="outline" />
        <BigButton icon={Mic} label="Analisar Voz" onClick={() => openVoiceTab("analyze")} tone="dark" />
        <BigButton icon={Target} label="Tom Ideal" onClick={() => openVoiceTab("tom")} tone="dark" />
      </div>
      <BigButton icon={Users2} label="Segunda Voz" sub="Harmonização automática" onClick={() => openVoiceTab("harmony")} tone="outline" className="mb-6" />
      {favorites.length > 0 && <Section title="❤️ Favoritas">{favorites.map((s) => <SongRow key={s.id} song={s} />)}</Section>}
      {lastSetlist && (
        <Section title="📋 Último setlist">
          <div className="rounded-xl bg-neutral-900 border border-neutral-800 px-4 py-3">
            <div className="text-white font-semibold">{lastSetlist.name}</div>
            <div className="text-neutral-500 text-xs mt-0.5">{lastSetlist.songIds.length} músicas</div>
          </div>
        </Section>
      )}
      {recents.length > 0 && <Section title="🕒 Usadas recentemente">{recents.map((s, i) => <SongRow key={s.id + i} song={s} />)}</Section>}
    </div>
  );
}

/* ============================================================
   LIBRARY
   ============================================================ */
function LibraryScreen({ songs, setSongs, onOpenSong, onImport }) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("Todas");
  const fileRef = useRef(null);
  const filtered = songs.filter((s) => {
    const matchQ = !query || [s.title, s.artist, s.genre, s.originalKey].join(" ").toLowerCase().includes(query.toLowerCase());
    const matchF = filter === "Todas" || (filter === "Favoritas" ? s.favorite : s.genre === filter);
    return matchQ && matchF;
  });
  const toggleFav = (id) => setSongs((prev) => prev.map((s) => (s.id === id ? { ...s, favorite: !s.favorite } : s)));
  return (
    <div className="pb-28">
      <TopBar title="Minhas Músicas" right={<button onClick={() => fileRef.current?.click()} className="bg-red-600 text-white rounded-full p-2"><Plus size={20} /></button>} />
      <input ref={fileRef} type="file" accept="audio/mpeg,audio/wav,audio/x-m4a,audio/mp4,.mp3,.wav,.m4a" multiple className="hidden"
        onChange={(e) => { onImport(e.target.files); e.target.value = ""; }} />
      <div className="px-4 pt-3">
        <div className="relative mb-3">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar por nome, artista, tom..."
            className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-9 pr-3 py-2.5 text-white text-sm outline-none focus:border-red-600" />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-3 -mx-4 px-4 no-scrollbar">
          {["Todas", "Favoritas", ...GENRES].map((g) => (
            <button key={g} onClick={() => setFilter(g)} className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border ${filter === g ? "bg-red-600 border-red-600 text-white" : "bg-transparent border-neutral-700 text-neutral-400"}`}>{g}</button>
          ))}
        </div>
      </div>
      <div className="px-4 space-y-2">
        {filtered.length === 0 ? (
          <EmptyState icon={Music} title="Nenhuma música encontrada" sub="Toque em + para importar MP3, WAV ou M4A" />
        ) : filtered.map((s) => <SongRow key={s.id} song={s} onClick={() => onOpenSong(s)} onToggleFav={toggleFav} />)}
      </div>
    </div>
  );
}
function Field({ label, children }) {
  return <div><div className="text-neutral-400 text-xs font-semibold mb-1.5">{label}</div>{children}</div>;
}
function SongEditScreen({ song, onSave, onDelete, onBack }) {
  const [form, setForm] = useState(song);
  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  return (
    <div className="pb-28">
      <TopBar title="Editar Música" onBack={onBack} right={<button onClick={() => onSave(form)} className="text-red-500 font-bold text-sm px-2">Salvar</button>} />
      <div className="px-4 pt-4 space-y-4">
        <Field label="Título"><input className="input" value={form.title} onChange={(e) => update("title", e.target.value)} /></Field>
        <Field label="Artista"><input className="input" value={form.artist} onChange={(e) => update("artist", e.target.value)} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Gênero"><select className="input" value={form.genre} onChange={(e) => update("genre", e.target.value)}>{GENRES.map((g) => <option key={g} value={g}>{g}</option>)}</select></Field>
          <Field label="Tom original"><select className="input" value={form.originalKey} onChange={(e) => update("originalKey", e.target.value)}>{NOTES_SHARP.map((n) => <option key={n} value={n}>{n}</option>)}</select></Field>
        </div>
        <Field label="BPM"><input type="number" className="input" value={form.bpm} onChange={(e) => update("bpm", Number(e.target.value))} /></Field>
        <Field label="Letra com cifra">
          <textarea className="input h-40 font-mono text-xs" placeholder="Use colchetes para marcar acordes: [G]Amazing [C]grace how [D]sweet..."
            value={form.lyrics} onChange={(e) => update("lyrics", e.target.value)} />
        </Field>
        <button onClick={() => onDelete(form.id)} className="flex items-center gap-2 text-red-500 text-sm font-semibold pt-2"><Trash2 size={16} /> Excluir música</button>
      </div>
      <style>{`.input{width:100%;background:#171717;border:1px solid #262626;border-radius:0.75rem;padding:0.65rem 0.85rem;color:white;font-size:0.9rem;outline:none} .input:focus{border-color:#dc2626}`}</style>
    </div>
  );
}

/* ============================================================
   PLAYER
   ============================================================ */
function PlayerScreen({ song, engine, onBack, onNext, onPrev, autoNext, setAutoNext, repeat, setRepeat, onUpdateSong, showMode, onExitShow, nextSongName }) {
  const [view, setView] = useState("player");
  const [fontSize, setFontSize] = useState(22);
  const [autoScroll, setAutoScroll] = useState(false);
  const [scrollSpeed, setScrollSpeed] = useState(30);
  const lyricsRef = useRef(null);
  const scrollTimer = useRef(null);

  useEffect(() => {
    if (autoScroll && lyricsRef.current) {
      scrollTimer.current = setInterval(() => { if (lyricsRef.current) lyricsRef.current.scrollTop += 1; }, 610 - scrollSpeed * 5.5);
    }
    return () => clearInterval(scrollTimer.current);
  }, [autoScroll, scrollSpeed]);

  const semitones = song.semitoneOffset || 0;
  const changeSemitones = (delta) => {
    const next = Math.max(-11, Math.min(11, semitones + delta));
    engine.setSemitones(next);
    onUpdateSong({ ...song, semitoneOffset: next });
  };
  const currentKey = transposeKey(song.originalKey, semitones);

  return (
    <div className={`pb-28 ${showMode ? "min-h-screen" : ""}`}>
      <TopBar title={showMode ? "MODO SHOW" : "Tocando agora"} onBack={showMode ? undefined : onBack}
        right={showMode ? <button onClick={onExitShow} className="text-neutral-400 flex items-center gap-1 text-xs font-semibold"><Minimize2 size={16} /> Sair</button> : null} />
      <div className="px-4 pt-2">
        <div className={`rounded-2xl bg-gradient-to-b from-neutral-900 to-black border border-neutral-800 p-5 mb-4 ${showMode ? "py-8" : ""}`}>
          <div className={`text-white font-black leading-tight ${showMode ? "text-3xl" : "text-2xl"}`}>{song.title}</div>
          <div className="text-neutral-400 text-sm mt-0.5">{song.artist}</div>
          <div className="flex items-center gap-4 mt-4">
            <div className="flex-1">
              <div className="text-neutral-500 text-[10px] font-bold uppercase tracking-wider">Tom atual</div>
              <div className={`text-red-500 font-black ${showMode ? "text-4xl" : "text-3xl"}`}>{currentKey}</div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => changeSemitones(-1)} className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center active:scale-95"><Minus size={18} className="text-white" /></button>
              <button onClick={() => changeSemitones(1)} className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center active:scale-95"><Plus size={18} className="text-white" /></button>
            </div>
            <div className="text-right">
              <div className="text-neutral-500 text-[10px] font-bold uppercase tracking-wider">BPM</div>
              <div className="text-white font-bold text-lg">{song.bpm || "—"}</div>
            </div>
          </div>
          {semitones !== 0 && <div className="text-neutral-500 text-xs mt-1">Tom original: {song.originalKey} ({semitones > 0 ? "+" : ""}{semitones} semitons)</div>}
        </div>

        {engine.error && <div className="flex items-center gap-2 bg-red-950 border border-red-900 text-red-400 text-sm rounded-xl px-3 py-2 mb-4"><AlertCircle size={16} /> {engine.error}</div>}

        <div className="mb-2">
          <input type="range" min={0} max={engine.duration || 0} step={0.1} value={Math.min(engine.position, engine.duration || 0)} onChange={(e) => engine.seek(Number(e.target.value))} className="w-full accent-red-600" />
          <div className="flex justify-between text-neutral-500 text-xs"><span>{fmtTime(engine.position)}</span><span>{fmtTime(engine.duration)}</span></div>
        </div>

        <div className={`flex items-center justify-center gap-6 ${showMode ? "my-6" : "my-3"}`}>
          <button onClick={onPrev} className="text-white active:scale-90"><SkipBack size={showMode ? 34 : 28} fill="currentColor" /></button>
          <button onClick={() => (engine.isPlaying ? engine.pause() : engine.play())} disabled={engine.isLoading}
            className={`bg-red-600 rounded-full flex items-center justify-center active:scale-95 disabled:opacity-50 ${showMode ? "w-20 h-20" : "w-16 h-16"}`}>
            {engine.isLoading ? <span className="text-white text-xs">...</span> : engine.isPlaying ? <Pause size={showMode ? 34 : 28} className="text-white" fill="white" /> : <Play size={showMode ? 34 : 28} className="text-white ml-1" fill="white" />}
          </button>
          <button onClick={onNext} className="text-white active:scale-90"><SkipForward size={showMode ? 34 : 28} fill="currentColor" /></button>
        </div>

        {nextSongName && <div className="text-center text-neutral-500 text-xs mb-4">Próxima: <span className="text-neutral-300 font-semibold">{nextSongName}</span></div>}

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3">
            <div className="flex items-center gap-1.5 text-neutral-400 text-xs font-semibold mb-1"><Gauge size={13} /> Velocidade {engine.speed.toFixed(2)}x</div>
            <input type="range" min={0.5} max={1.5} step={0.05} value={engine.speed} onChange={(e) => engine.setSpeed(Number(e.target.value))} className="w-full accent-red-600" />
          </div>
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3">
            <div className="flex items-center gap-1.5 text-neutral-400 text-xs font-semibold mb-1"><Volume2 size={13} /> Volume</div>
            <input type="range" min={0} max={1} step={0.02} value={engine.volume} onChange={(e) => engine.setVolume(Number(e.target.value))} className="w-full accent-red-600" />
          </div>
        </div>

        <div className="flex gap-2 mb-4">
          <button onClick={() => setRepeat(!repeat)} className={`flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-bold border ${repeat ? "bg-red-600 border-red-600 text-white" : "bg-neutral-900 border-neutral-800 text-neutral-400"}`}><Repeat size={14} /> Repetir</button>
          <button onClick={() => setAutoNext(!autoNext)} className={`flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-bold border ${autoNext ? "bg-red-600 border-red-600 text-white" : "bg-neutral-900 border-neutral-800 text-neutral-400"}`}><SkipForward size={14} /> Próxima automática</button>
        </div>

        <div className="flex gap-2 mb-4">
          <button onClick={() => setView("player")} className={`flex-1 rounded-xl py-2.5 text-sm font-bold ${view === "player" ? "bg-white text-black" : "bg-neutral-900 text-neutral-400"}`}>Controles</button>
          <button onClick={() => setView("lyrics")} className={`flex-1 rounded-xl py-2.5 text-sm font-bold ${view === "lyrics" ? "bg-white text-black" : "bg-neutral-900 text-neutral-400"}`}>Letra & Cifra</button>
        </div>

        {view === "lyrics" && (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <button onClick={() => setFontSize((f) => Math.max(14, f - 2))} className="w-9 h-9 rounded-lg bg-neutral-800 text-white font-bold">A-</button>
              <button onClick={() => setFontSize((f) => Math.min(40, f + 2))} className="w-9 h-9 rounded-lg bg-neutral-800 text-white font-bold">A+</button>
              <button onClick={() => setAutoScroll((a) => !a)} className={`flex-1 rounded-lg text-xs font-bold py-2 ${autoScroll ? "bg-red-600 text-white" : "bg-neutral-800 text-neutral-300"}`}>{autoScroll ? "Pausar rolagem" : "Iniciar rolagem"}</button>
              <button onClick={() => { setAutoScroll(false); if (lyricsRef.current) lyricsRef.current.scrollTop = 0; }} className="w-9 h-9 rounded-lg bg-neutral-800 text-white text-xs font-bold">⟲</button>
            </div>
            <input type="range" min={5} max={100} value={scrollSpeed} onChange={(e) => setScrollSpeed(Number(e.target.value))} className="w-full accent-red-600 mb-3" />
            <div ref={lyricsRef} className={`bg-neutral-950 border border-neutral-800 rounded-2xl p-5 leading-relaxed whitespace-pre-wrap overflow-y-auto ${showMode ? "h-[52vh]" : "h-72"}`} style={{ fontSize }}>
              {song.lyrics ? <div className="text-neutral-100">{renderChordLyric(song.lyrics, semitones)}</div> : <span className="text-neutral-600 text-sm">Nenhuma letra/cifra cadastrada para esta música.</span>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================
   SETLISTS
   ============================================================ */
function SetlistsScreen({ setlists, setSetlists, songs, onOpenSetlist }) {
  const create = () => { const name = prompt("Nome do novo setlist:"); if (!name) return; setSetlists((prev) => [...prev, { id: uid(), name, songIds: [], createdAt: Date.now() }]); };
  const duplicate = (sl) => setSetlists((prev) => [...prev, { ...sl, id: uid(), name: sl.name + " (cópia)" }]);
  const remove = (id) => setSetlists((prev) => prev.filter((s) => s.id !== id));
  const totalDuration = (sl) => sl.songIds.reduce((acc, id) => acc + (songs.find((x) => x.id === id)?.durationSec || 0), 0);
  return (
    <div className="pb-28">
      <TopBar title="Meus Setlists" right={<button onClick={create} className="bg-red-600 text-white rounded-full p-2"><Plus size={20} /></button>} />
      <div className="px-4 pt-3 space-y-3">
        {setlists.length === 0 ? <EmptyState icon={ListMusic} title="Nenhum setlist criado" sub="Toque em + para criar seu primeiro setlist" /> : setlists.map((sl) => (
          <div key={sl.id} className="bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3">
            <div className="flex items-center justify-between">
              <div onClick={() => onOpenSetlist(sl)} className="min-w-0 flex-1 cursor-pointer">
                <div className="text-white font-bold">{sl.name}</div>
                <div className="text-neutral-500 text-xs mt-0.5">{sl.songIds.length} músicas • {fmtTime(totalDuration(sl))}</div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => duplicate(sl)} className="p-2 text-neutral-400"><ListPlus size={16} /></button>
                <button onClick={() => remove(sl.id)} className="p-2 text-red-500"><Trash2 size={16} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
function SetlistDetailScreen({ setlist, setSetlists, songs, onBack, onPlay }) {
  const list = setlist.songIds.map((id) => songs.find((s) => s.id === id)).filter(Boolean);
  const [adding, setAdding] = useState(false);
  const update = (fn) => setSetlists((prev) => prev.map((s) => (s.id === setlist.id ? fn(s) : s)));
  const removeSong = (id) => update((s) => ({ ...s, songIds: s.songIds.filter((x) => x !== id) }));
  const move = (idx, dir) => update((s) => { const arr = [...s.songIds]; const j = idx + dir; if (j < 0 || j >= arr.length) return s; [arr[idx], arr[j]] = [arr[j], arr[idx]]; return { ...s, songIds: arr }; });
  const addSong = (id) => update((s) => (s.songIds.includes(id) ? s : { ...s, songIds: [...s.songIds, id] }));
  const totalDuration = list.reduce((acc, s) => acc + (s.durationSec || 0), 0);
  const rename = () => { const name = prompt("Novo nome do setlist:", setlist.name); if (name) update((s) => ({ ...s, name })); };
  return (
    <div className="pb-28">
      <TopBar title={setlist.name} onBack={onBack} right={<button onClick={rename}><Edit3 size={18} className="text-neutral-400" /></button>} />
      <div className="px-4 pt-3">
        <div className="text-neutral-500 text-xs mb-3">{list.length} músicas • duração total {fmtTime(totalDuration)}</div>
        <button onClick={() => onPlay(setlist, 0)} disabled={!list.length} className="w-full mb-4 rounded-xl bg-red-600 disabled:bg-neutral-800 disabled:text-neutral-600 text-white font-bold py-3 flex items-center justify-center gap-2"><Play size={18} fill="currentColor" /> Tocar Setlist</button>
        <div className="space-y-2 mb-5">
          {list.map((s, i) => (
            <div key={s.id} className="flex items-center gap-3 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2.5">
              <div className="text-neutral-500 font-bold text-sm w-5">{i + 1}</div>
              <div className="flex-1 min-w-0" onClick={() => onPlay(setlist, i)}>
                <div className="text-white font-semibold text-sm truncate">{s.title}</div>
                <div className="text-neutral-500 text-xs">Tom: {transposeKey(s.originalKey, s.semitoneOffset || 0)}</div>
              </div>
              <div className="flex flex-col"><button onClick={() => move(i, -1)} className="text-neutral-500"><ChevronUp size={14} /></button><button onClick={() => move(i, 1)} className="text-neutral-500"><ChevronDown size={14} /></button></div>
              <button onClick={() => removeSong(s.id)} className="text-red-500 p-1"><X size={16} /></button>
            </div>
          ))}
        </div>
        <button onClick={() => setAdding((a) => !a)} className="flex items-center gap-2 text-red-500 font-bold text-sm mb-3"><Plus size={16} /> Adicionar música</button>
        {adding && <div className="space-y-2 max-h-64 overflow-y-auto">{songs.filter((s) => !setlist.songIds.includes(s.id)).map((s) => <SongRow key={s.id} song={s} onClick={() => addSong(s.id)} />)}</div>}
      </div>
    </div>
  );
}

/* ============================================================
   FASE 2 — ANALISADOR VOCAL EM TEMPO REAL
   ============================================================ */
function VocalAnalyzerTab() {
  const [active, setActive] = useState(false);
  const { note, noteClarity, error } = useVocalGuitarListener(active, "voice-only");
  const [minMidi, setMinMidi] = useState(null);
  const [maxMidi, setMaxMidi] = useState(null);
  const [history, setHistory] = useState([]); // cents history for graph

  useEffect(() => {
    if (!active) { setMinMidi(null); setMaxMidi(null); setHistory([]); return; }
  }, [active]);

  useEffect(() => {
    if (!active || !note || noteClarity < 0.9) return;
    setMinMidi((m) => (m === null ? note.midi : Math.min(m, note.midi)));
    setMaxMidi((m) => (m === null ? note.midi : Math.max(m, note.midi)));
    setHistory((h) => [...h.slice(-59), note.cents]);
  }, [note, noteClarity, active]);

  return (
    <div className="px-4 pt-4">
      <PermissionNotice error={error} />
      <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 text-center mb-4">
        <div className="text-neutral-500 text-xs font-bold uppercase tracking-wider mb-1">Nota detectada</div>
        <div className="text-red-500 font-black text-5xl mb-1">{note && noteClarity > 0.9 ? note.name : "—"}</div>
        <div className="text-neutral-500 text-xs">{note && noteClarity > 0.9 ? `${note.freq.toFixed(1)} Hz • ${note.cents > 0 ? "+" : ""}${note.cents} cents` : active ? "Cante ou toque uma nota perto do microfone" : "Toque em iniciar para começar"}</div>
      </div>

      <div className="mb-4">
        <div className="text-neutral-400 text-xs font-semibold mb-1.5">Afinação (desvio em cents)</div>
        <svg viewBox="0 0 300 60" className="w-full h-16 bg-neutral-950 border border-neutral-800 rounded-xl">
          <line x1="0" y1="30" x2="300" y2="30" stroke="#404040" strokeWidth="1" strokeDasharray="3,3" />
          {history.length > 1 && (
            <polyline
              fill="none" stroke="#dc2626" strokeWidth="2"
              points={history.map((c, i) => `${(i / Math.max(1, history.length - 1)) * 300},${30 - Math.max(-50, Math.min(50, c)) * 0.55}`).join(" ")}
            />
          )}
        </svg>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 text-center">
          <div className="text-neutral-500 text-[10px] font-bold uppercase">Mais grave</div>
          <div className="text-white font-bold text-xl">{minMidi !== null ? nameFromMidi(minMidi) : "—"}</div>
        </div>
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 text-center">
          <div className="text-neutral-500 text-[10px] font-bold uppercase">Mais aguda</div>
          <div className="text-white font-bold text-xl">{maxMidi !== null ? nameFromMidi(maxMidi) : "—"}</div>
        </div>
      </div>
      {minMidi !== null && maxMidi !== null && (
        <div className="text-center text-neutral-400 text-sm mb-4">Extensão utilizada nesta sessão: <span className="text-white font-semibold">{nameFromMidi(minMidi)} – {nameFromMidi(maxMidi)}</span></div>
      )}

      <button onClick={() => setActive((a) => !a)} className={`w-full rounded-xl py-3.5 font-bold flex items-center justify-center gap-2 ${active ? "bg-neutral-800 text-white" : "bg-red-600 text-white"}`}>
        <Mic size={18} /> {active ? "Parar análise" : "Iniciar análise"}
      </button>
      <div className="text-neutral-600 text-xs text-center mt-3">Processamento 100% local, no aparelho. Nenhum áudio é enviado a servidores.</div>
    </div>
  );
}

/* ============================================================
   FASE 2 — ENCONTRAR MEU TOM / TESTAR VÁRIOS TONS
   ============================================================ */
function TomIdealTab({ songs, updateSong, onGenerateReport }) {
  const [songId, setSongId] = useState(songs[0]?.id || "");
  const song = songs.find((s) => s.id === songId);
  const [candidateOffset, setCandidateOffset] = useState(0);
  const [listening, setListening] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [results, setResults] = useState([]);
  const samplesRef = useRef([]);
  const { note, noteClarity, error } = useVocalGuitarListener(listening, "voice-only");

  useEffect(() => { if (listening && note && noteClarity > 0.85) samplesRef.current.push({ midi: note.midi, clarity: noteClarity }); }, [note, noteClarity, listening]);

  const startCapture = () => { samplesRef.current = []; setListening(true); setCountdown(8); };
  useEffect(() => {
    if (!listening) return;
    if (countdown <= 0) { finish(); return; }
    const t = setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [listening, countdown]); // eslint-disable-line

  const finish = () => {
    setListening(false);
    const samples = samplesRef.current;
    const key = transposeKey(song.originalKey, candidateOffset);
    if (samples.length < 6) {
      setResults((r) => [...r, { offset: candidateOffset, key, score: null, note: "Sinal insuficiente. Aproxime-se do microfone e cante um trecho maior." }]);
      return;
    }
    const clear = samples.filter((s) => s.clarity > 0.93);
    const pct = clear.length / samples.length;
    const midis = clear.length ? clear.map((s) => s.midi) : samples.map((s) => s.midi);
    const min = Math.min(...midis), max = Math.max(...midis);
    const score = Math.round(pct * 100);
    setResults((r) => [...r, { offset: candidateOffset, key, score, minNote: nameFromMidi(min), maxNote: nameFromMidi(max), clearPct: score }]);
  };

  const validResults = results.filter((r) => r.score != null).sort((a, b) => b.score - a.score);
  const best = validResults[0];

  return (
    <div className="px-4 pt-4">
      {!songs.length ? <EmptyState icon={Target} title="Importe uma música primeiro" /> : (
        <>
          <Field label="Música">
            <select value={songId} onChange={(e) => { setSongId(e.target.value); setResults([]); setCandidateOffset(0); }} className="input">
              {songs.map((s) => <option key={s.id} value={s.id}>{s.title}</option>)}
            </select>
          </Field>

          {song && (
            <>
              <div className="grid grid-cols-2 gap-3 my-4">
                <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 text-center">
                  <div className="text-neutral-500 text-[10px] font-bold uppercase">Tom original</div>
                  <div className="text-white font-bold text-2xl">{song.originalKey}</div>
                </div>
                <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 text-center">
                  <div className="text-neutral-500 text-[10px] font-bold uppercase">Testando</div>
                  <div className="text-red-500 font-bold text-2xl">{transposeKey(song.originalKey, candidateOffset)}</div>
                </div>
              </div>

              <div className="flex items-center justify-center gap-4 mb-4">
                <button onClick={() => setCandidateOffset((o) => Math.max(-11, o - 1))} className="w-11 h-11 rounded-full bg-neutral-800 text-white flex items-center justify-center"><Minus size={18} /></button>
                <div className="text-neutral-400 text-sm w-20 text-center">{candidateOffset > 0 ? "+" : ""}{candidateOffset} semitons</div>
                <button onClick={() => setCandidateOffset((o) => Math.min(11, o + 1))} className="w-11 h-11 rounded-full bg-neutral-800 text-white flex items-center justify-center"><Plus size={18} /></button>
              </div>

              <PermissionNotice error={error} />

              <button onClick={startCapture} disabled={listening} className="w-full rounded-xl bg-red-600 disabled:opacity-60 text-white font-bold py-3.5 flex items-center justify-center gap-2 mb-2">
                <Mic size={18} /> {listening ? `Cantando... ${countdown}s` : "Cantar agora neste tom (8s)"}
              </button>
              <div className="text-neutral-600 text-xs text-center mb-5">Cante um trecho da música neste tom. O app grava suas notas em tempo real (localmente) para comparar.</div>

              {results.length > 0 && (
                <div className="mb-5">
                  <div className="text-neutral-400 text-xs font-bold uppercase tracking-wider mb-2">Resultados desta sessão</div>
                  <div className="space-y-2">
                    {results.map((r, i) => (
                      <div key={i} className="bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3">
                        <div className="flex items-center justify-between mb-1">
                          <div className="text-white font-bold flex items-center gap-1.5">{r.key} {best && r.offset === best.offset && <Star size={14} className="text-red-500 fill-red-500" />}</div>
                          {r.score != null && <div className="text-white font-bold">{r.score}%</div>}
                        </div>
                        {r.score != null ? (
                          <>
                            <ScoreBar score={r.score} />
                            <div className="text-neutral-500 text-xs mt-1">Extensão captada: {r.minNote} – {r.maxNote}</div>
                          </>
                        ) : <div className="text-neutral-500 text-xs">{r.note}</div>}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {best && (
                <div className="bg-neutral-900 border border-red-900/50 rounded-2xl p-5 mb-4">
                  <div className="text-neutral-500 text-xs font-bold uppercase tracking-wider mb-1">Seu tom ideal (nesta sessão)</div>
                  <div className="text-red-500 font-black text-4xl mb-2">{best.key}</div>
                  <div className="text-neutral-400 text-sm mb-1">Conforto vocal: <span className="text-white font-semibold">{best.score}%</span></div>
                  <div className="text-neutral-400 text-sm mb-3">Extensão utilizada: <span className="text-white font-semibold">{best.minNote} – {best.maxNote}</span></div>
                  <p className="text-neutral-500 text-xs leading-relaxed mb-4">
                    Esta indicação é baseada na análise realizada nesta sessão de canto — não é uma avaliação médica ou fisiológica.
                    {best.key} apresentou o melhor resultado entre os tons testados.
                  </p>
                  <div className="flex gap-2">
                    <button onClick={() => { updateSong({ ...song, semitoneOffset: best.offset }); alert(`Tom ${best.key} salvo para "${song.title}".`); }} className="flex-1 bg-red-600 text-white font-bold rounded-xl py-2.5 text-sm flex items-center justify-center gap-1.5"><Check size={15} /> Usar este tom</button>
                    <button onClick={() => onGenerateReport({ song, results: validResults, best })} className="flex-1 bg-neutral-800 text-white font-bold rounded-xl py-2.5 text-sm flex items-center justify-center gap-1.5"><FileText size={15} /> Relatório PDF</button>
                  </div>
                </div>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
}

/* ============================================================
   FASE 3 — VOZ + VIOLÃO / DETECÇÃO DE ACORDES
   ============================================================ */
function VoiceGuitarTab() {
  const [mode, setMode] = useState("voice-only"); // voice-only | both | guitar-ref
  const [active, setActive] = useState(false);
  const { note, noteClarity, chord, chordConfidence, error } = useVocalGuitarListener(active, mode);
  const modes = [
    { id: "voice-only", label: "Somente voz", icon: Mic },
    { id: "both", label: "Voz + Violão", icon: Guitar },
    { id: "guitar-ref", label: "Violão referência", icon: Radio },
  ];
  return (
    <div className="px-4 pt-4">
      <div className="grid grid-cols-3 gap-2 mb-4">
        {modes.map((m) => (
          <button key={m.id} onClick={() => setMode(m.id)} className={`rounded-xl py-3 flex flex-col items-center gap-1 text-[11px] font-bold ${mode === m.id ? "bg-white text-black" : "bg-neutral-900 text-neutral-400 border border-neutral-800"}`}>
            <m.icon size={16} /> {m.label}
          </button>
        ))}
      </div>
      <PermissionNotice error={error} />

      {mode !== "guitar-ref" && (
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-5 text-center mb-3">
          <div className="text-neutral-500 text-xs font-bold uppercase tracking-wider mb-1">Nota da voz</div>
          <div className="text-red-500 font-black text-4xl">{note && noteClarity > 0.9 ? note.name : "—"}</div>
        </div>
      )}
      {mode !== "voice-only" && (
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-5 text-center mb-3">
          <div className="text-neutral-500 text-xs font-bold uppercase tracking-wider mb-1">Acorde detectado</div>
          {chord ? (
            <>
              <div className="text-white font-black text-4xl mb-1 flex items-center justify-center gap-2"><Guitar size={26} className="text-red-500" />{chord.name}</div>
              <div className="text-neutral-500 text-xs">Confiança: {Math.round(chordConfidence * 100)}%</div>
            </>
          ) : <div className="text-neutral-600 text-sm">{active ? "Aguardando sinal mais claro..." : "Toque em iniciar"}</div>}
        </div>
      )}

      <button onClick={() => setActive((a) => !a)} className={`w-full rounded-xl py-3.5 font-bold flex items-center justify-center gap-2 ${active ? "bg-neutral-800 text-white" : "bg-red-600 text-white"}`}>
        <Mic size={18} /> {active ? "Parar escuta" : "Iniciar escuta"}
      </button>
      <div className="text-neutral-600 text-xs text-center mt-3 leading-relaxed">
        A detecção de acordes usa análise espectral real do microfone (perfil de classes de altura). Quando o sinal não for claro o suficiente, nenhum acorde é inventado.
      </div>
    </div>
  );
}

/* ============================================================
   FASE 3 — SEGUNDA VOZ / HARMONIZAÇÃO
   ============================================================ */
function SegundaVozTab({ songs }) {
  const [songId, setSongId] = useState(songs[0]?.id || "");
  const song = songs.find((s) => s.id === songId);
  const [mode, setMode] = useState("terca-acima");
  const [active, setActive] = useState(false);
  const [mainVol, setMainVol] = useState(100);
  const [harmVol, setHarmVol] = useState(70);
  const [latency, setLatency] = useState("baixa");
  const { note, error: listenError } = useVocalGuitarListener(active, "voice-only");
  const nodesRef = useRef({});
  const [engineError, setEngineError] = useState(null);

  const modes = [
    { id: "terca-acima", label: "Terça acima" }, { id: "terca-abaixo", label: "Terça abaixo" },
    { id: "quinta", label: "Quinta" }, { id: "oitava-acima", label: "Oitava acima" },
    { id: "oitava-abaixo", label: "Oitava abaixo" }, { id: "inteligente", label: "Harmonia inteligente" },
  ];

  useEffect(() => {
    if (!active) { cleanup(); return; }
    (async () => {
      try {
        await Tone.start();
        const mic = new Tone.UserMedia(); await mic.open();
        const pitchShift = new Tone.PitchShift({ windowSize: latency === "baixa" ? 0.03 : latency === "media" ? 0.06 : 0.1 });
        const harmVolNode = new Tone.Volume(Tone.gainToDb(harmVol / 100));
        const mainVolNode = new Tone.Volume(Tone.gainToDb(mainVol / 100));
        mic.connect(pitchShift); pitchShift.connect(harmVolNode); harmVolNode.toDestination();
        mic.connect(mainVolNode); mainVolNode.toDestination();
        nodesRef.current = { mic, pitchShift, harmVolNode, mainVolNode };
        setEngineError(null);
      } catch (e) { setEngineError("Não foi possível acessar o microfone para gerar a segunda voz."); }
    })();
    return cleanup;
    function cleanup() {
      const { mic, pitchShift, harmVolNode, mainVolNode } = nodesRef.current;
      try { mic && mic.close(); } catch {}
      try { pitchShift && pitchShift.dispose(); } catch {}
      try { harmVolNode && harmVolNode.dispose(); } catch {}
      try { mainVolNode && mainVolNode.dispose(); } catch {}
      nodesRef.current = {};
    }
  }, [active, latency]); // eslint-disable-line

  useEffect(() => { if (nodesRef.current.harmVolNode) nodesRef.current.harmVolNode.volume.value = Tone.gainToDb(Math.max(0.0001, harmVol / 100)); }, [harmVol]);
  useEffect(() => { if (nodesRef.current.mainVolNode) nodesRef.current.mainVolNode.volume.value = Tone.gainToDb(Math.max(0.0001, mainVol / 100)); }, [mainVol]);

  useEffect(() => {
    if (!nodesRef.current.pitchShift || !note || !song) return;
    const key = song.originalKey || "C";
    let semi;
    if (mode === "terca-acima") semi = diatonicInterval(note.midi, key, 2);
    else if (mode === "terca-abaixo") semi = diatonicInterval(note.midi, key, 2) - 12;
    else if (mode === "quinta") semi = diatonicInterval(note.midi, key, 4);
    else if (mode === "oitava-acima") semi = 12;
    else if (mode === "oitava-abaixo") semi = -12;
    else semi = diatonicInterval(note.midi, key, 2); // harmonia inteligente (versão simplificada: terça diatônica)
    nodesRef.current.pitchShift.pitch = semi;
  }, [note, mode, song]);

  return (
    <div className="px-4 pt-4">
      {!songs.length ? <EmptyState icon={Users2} title="Importe uma música primeiro" /> : (
        <>
          <Field label="Música (define o tom para a harmonia)">
            <select value={songId} onChange={(e) => setSongId(e.target.value)} className="input">{songs.map((s) => <option key={s.id} value={s.id}>{s.title} — Tom {s.originalKey}</option>)}</select>
          </Field>

          <div className="grid grid-cols-2 gap-2 my-4">
            {modes.map((m) => (
              <button key={m.id} onClick={() => setMode(m.id)} className={`rounded-xl py-2.5 text-xs font-bold ${mode === m.id ? "bg-red-600 text-white" : "bg-neutral-900 text-neutral-400 border border-neutral-800"}`}>{m.label}</button>
            ))}
          </div>

          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 mb-3">
            <div className="text-neutral-400 text-xs font-semibold mb-1">Voz principal — {mainVol}%</div>
            <input type="range" min={0} max={100} value={mainVol} onChange={(e) => setMainVol(Number(e.target.value))} className="w-full accent-red-600" />
          </div>
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 mb-3">
            <div className="text-neutral-400 text-xs font-semibold mb-1">Segunda voz — {harmVol}%</div>
            <input type="range" min={0} max={100} value={harmVol} onChange={(e) => setHarmVol(Number(e.target.value))} className="w-full accent-red-600" />
          </div>

          <Field label="Latência">
            <div className="flex gap-2">
              {["baixa", "media", "alta"].map((l) => (
                <button key={l} onClick={() => setLatency(l)} className={`flex-1 rounded-lg py-2 text-xs font-bold capitalize ${latency === l ? "bg-white text-black" : "bg-neutral-900 text-neutral-400 border border-neutral-800"}`}>{l}</button>
              ))}
            </div>
          </Field>

          <PermissionNotice error={listenError || engineError} />

          <div className="flex items-center gap-2 bg-amber-950/40 border border-amber-900/50 text-amber-400 text-xs rounded-xl px-3 py-2.5 my-3">
            <Headphones size={15} className="flex-shrink-0" /> Use fones de ouvido para evitar retorno de áudio (efeito Larsen).
          </div>

          <button onClick={() => setActive((a) => !a)} className={`w-full rounded-xl py-3.5 font-bold flex items-center justify-center gap-2 mt-2 ${active ? "bg-neutral-800 text-white" : "bg-red-600 text-white"}`}>
            <Zap size={18} /> {active ? "Parar segunda voz" : "Ativar segunda voz ao vivo"}
          </button>
        </>
      )}
    </div>
  );
}

/* ============================================================
   VOICE HUB (Fases 2 e 3)
   ============================================================ */
function VoiceScreen({ songs, updateSong, onGenerateReport, initialTab }) {
  const [tab, setTab] = useState(initialTab || "analyze");
  useEffect(() => { if (initialTab) setTab(initialTab); }, [initialTab]);
  const tabs = [
    { id: "analyze", label: "Analisador", icon: Mic },
    { id: "tom", label: "Tom Ideal", icon: Target },
    { id: "guitar", label: "Voz+Violão", icon: Guitar },
    { id: "harmony", label: "2ª Voz", icon: Users2 },
  ];
  return (
    <div className="pb-28">
      <TopBar title="Análise Vocal" />
      <div className="flex gap-1.5 px-4 pt-3 overflow-x-auto no-scrollbar">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`flex-shrink-0 rounded-xl py-2.5 px-3 text-xs font-bold flex items-center gap-1.5 ${tab === t.id ? "bg-white text-black" : "bg-neutral-900 text-neutral-400"}`}><t.icon size={15} />{t.label}</button>
        ))}
      </div>
      {tab === "analyze" && <VocalAnalyzerTab />}
      {tab === "tom" && <TomIdealTab songs={songs} updateSong={updateSong} onGenerateReport={onGenerateReport} />}
      {tab === "guitar" && <VoiceGuitarTab />}
      {tab === "harmony" && <SegundaVozTab songs={songs} />}
    </div>
  );
}

/* ============================================================
   FASE 4 — ESTATÍSTICAS / HISTÓRICO
   ============================================================ */
function StatsScreen({ history, onBack }) {
  const counts = {};
  history.forEach((h) => { counts[h.songId] = counts[h.songId] || { title: h.title, artist: h.artist, count: 0 }; counts[h.songId].count += 1; });
  const ranked = Object.values(counts).sort((a, b) => b.count - a.count).slice(0, 10);
  const recent = [...history].reverse().slice(0, 15);
  return (
    <div className="pb-28">
      <TopBar title="Histórico e Estatísticas" onBack={onBack} />
      <div className="px-4 pt-4">
        <Section title="📊 Mais tocadas">
          {ranked.length === 0 ? <EmptyState icon={BarChart3} title="Ainda sem dados" sub="Toque músicas para gerar estatísticas" /> : ranked.map((r, i) => (
            <div key={i} className="flex items-center gap-3 bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5">
              <div className="text-neutral-500 font-bold text-sm w-5">{i + 1}</div>
              <div className="flex-1 min-w-0"><div className="text-white font-semibold text-sm truncate">{r.title}</div><div className="text-neutral-500 text-xs truncate">{r.artist}</div></div>
              <div className="text-red-500 font-bold text-sm">{r.count}x</div>
            </div>
          ))}
        </Section>
        {recent.length > 0 && (
          <Section title="🕒 Últimas execuções">
            {recent.map((h, i) => (
              <div key={i} className="flex items-center justify-between bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5">
                <div className="min-w-0"><div className="text-white font-semibold text-sm truncate">{h.title}</div><div className="text-neutral-500 text-xs">Tom {h.key} • {h.bpm} BPM</div></div>
                <div className="text-neutral-500 text-xs flex-shrink-0">{fmtDate(h.ts)}</div>
              </div>
            ))}
          </Section>
        )}
      </div>
    </div>
  );
}

/* ============================================================
   FASE 4 — RELATÓRIO PDF (via impressão real do navegador)
   ============================================================ */
function PrintReport({ data }) {
  if (!data) return null;
  const { song, results, best } = data;
  return (
    <div className="print-report">
      <div style={{ fontFamily: "sans-serif", color: "#111", padding: "32px" }}>
        <h1 style={{ fontSize: 22, marginBottom: 4 }}>LB CAP PLAYER — Relatório de Análise Vocal</h1>
        <p style={{ color: "#666", marginBottom: 24 }}>Gerado em {new Date().toLocaleString("pt-BR")}</p>
        <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: 24 }}>
          <tbody>
            {[
              ["Música", song.title], ["Artista", song.artist || "—"], ["Tom original", song.originalKey],
              ["Tom recomendado", best.key], ["Semitons de alteração", `${best.offset > 0 ? "+" : ""}${best.offset}`],
              ["Nota mais grave (sessão)", best.minNote], ["Nota mais aguda (sessão)", best.maxNote],
              ["Conforto vocal (afinação/estabilidade)", `${best.score}%`],
            ].map(([k, v]) => (
              <tr key={k} style={{ borderBottom: "1px solid #ddd" }}>
                <td style={{ padding: "6px 0", fontWeight: 600, width: "45%" }}>{k}</td><td style={{ padding: "6px 0" }}>{v}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <h3 style={{ fontSize: 14, marginBottom: 8 }}>Tons testados nesta sessão</h3>
        <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: 24 }}>
          <thead><tr><th style={{ textAlign: "left", borderBottom: "2px solid #111", padding: "4px 0" }}>Tom</th><th style={{ textAlign: "left", borderBottom: "2px solid #111" }}>Pontuação</th><th style={{ textAlign: "left", borderBottom: "2px solid #111" }}>Extensão</th></tr></thead>
          <tbody>{results.map((r, i) => <tr key={i}><td style={{ padding: "4px 0" }}>{r.key}</td><td>{r.score}%</td><td>{r.minNote} – {r.maxNote}</td></tr>)}</tbody>
        </table>
        <p style={{ fontSize: 12, color: "#555", lineHeight: 1.5 }}>
          Recomendação: o tom <strong>{best.key}</strong> apresentou o melhor resultado nesta sessão de análise.
          Esta indicação é baseada exclusivamente no sinal captado pelo microfone durante a sessão — não constitui
          avaliação médica, fonoaudiológica ou fisiológica.
        </p>
      </div>
    </div>
  );
}

/* ============================================================
   SETTINGS (inclui MIDI/Pedal — Fase 4)
   ============================================================ */
function SettingsScreen({ onClearAll, midi, mapping, capturing, setCapturing, pendingKey, assignAction }) {
  return (
    <div className="pb-28 px-4 pt-3">
      <TopBar title="Configurações" />
      <Section title="Privacidade">
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-sm text-neutral-300 leading-relaxed">
          Suas músicas, letras, cifras e setlists ficam salvos neste dispositivo/navegador. Toda análise de voz e
          detecção de acordes é processada localmente — nenhum áudio é enviado a servidores.
        </div>
      </Section>

      <Section title="🎛️ Pedal Bluetooth / MIDI">
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-sm text-neutral-300">
          {midi.supported === false && <div className="text-neutral-500">Este navegador/ambiente não expõe a Web MIDI API. Em um app instalado (PWA/nativo) com um pedal pareado via Bluetooth (perfil MIDI), a detecção funciona normalmente.</div>}
          {midi.supported === null && <div className="text-neutral-500">Verificando suporte MIDI...</div>}
          {midi.supported === true && (
            <>
              <div className="mb-2">Dispositivos detectados: {midi.deviceNames.length ? midi.deviceNames.join(", ") : "nenhum pareado"}</div>
              <button onClick={() => setCapturing(true)} disabled={capturing} className="w-full bg-red-600 disabled:opacity-60 text-white font-bold rounded-lg py-2.5 text-sm mb-2">
                {capturing ? "Aguardando você pressionar o pedal..." : "Detectar meu pedal"}
              </button>
              {pendingKey && (
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {[["next","Próxima música"],["prev","Música anterior"],["playpause","Play / Pause"],["scroll","Rolar letra"]].map(([act,label]) => (
                    <button key={act} onClick={() => assignAction(act)} className="bg-neutral-800 text-white text-xs font-semibold rounded-lg py-2">{label}</button>
                  ))}
                </div>
              )}
              {Object.keys(mapping).length > 0 && <div className="text-neutral-500 text-xs mt-2">{Object.keys(mapping).length} comando(s) configurado(s).</div>}
            </>
          )}
        </div>
      </Section>

      <Section title="Dados">
        <button onClick={onClearAll} className="flex items-center gap-2 bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-red-500 font-semibold text-sm w-full"><Trash2 size={16} /> Apagar todos os dados salvos</button>
      </Section>
      <div className="text-center text-neutral-700 text-xs mt-8">LB CAP PLAYER • Fases 1 a 4</div>
    </div>
  );
}

/* ============================================================
   APP
   ============================================================ */
export default function LBCapPlayer() {
  const [screen, setScreen] = useState("home");
  const [songs, setSongs] = useState([]);
  const [setlists, setSetlists] = useState([]);
  const [history, setHistory] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [editingSong, setEditingSong] = useState(null);
  const [activeSong, setActiveSong] = useState(null);
  const [activeSetlist, setActiveSetlist] = useState(null);
  const [openSetlist, setOpenSetlist] = useState(null);
  const [showMode, setShowMode] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [autoNext, setAutoNext] = useState(true);
  const [voiceTab, setVoiceTab] = useState("analyze");
  const [showStats, setShowStats] = useState(false);
  const [reportData, setReportData] = useState(null);
  const [midiMapping, setMidiMapping] = useState({});
  const [capturingMidi, setCapturingMidi] = useState(false);
  const [pendingMidiKey, setPendingMidiKey] = useState(null);
  const audioUrlMap = useRef({});

  const engine = useAudioEngine({
    onEnded: () => {
      if (repeat) { engine.seek(0); engine.play(); return; }
      if (autoNext && activeSetlist) goNext();
    },
  });

  useEffect(() => {
    (async () => {
      setSongs(await storageGet(K_SONGS, []));
      setSetlists(await storageGet(K_SETLISTS, []));
      setHistory(await storageGet(K_HISTORY, []));
      setMidiMapping(await storageGet(K_MIDI, {}));
      setLoaded(true);
    })();
  }, []);
  useEffect(() => { if (loaded) storageSet(K_SONGS, songs.map(({ file, ...rest }) => rest)); }, [songs, loaded]);
  useEffect(() => { if (loaded) storageSet(K_SETLISTS, setlists); }, [setlists, loaded]);
  useEffect(() => { if (loaded) storageSet(K_HISTORY, history.slice(-200)); }, [history, loaded]);
  useEffect(() => { if (loaded) storageSet(K_MIDI, midiMapping); }, [midiMapping, loaded]);

  const importFiles = (fileList) => {
    const files = Array.from(fileList);
    const newSongs = files.map((file) => {
      const id = uid();
      audioUrlMap.current[id] = URL.createObjectURL(file);
      return { id, title: file.name.replace(/\.[^/.]+$/, ""), artist: "", genre: "Voz e Violão", originalKey: "C", semitoneOffset: 0, bpm: 90, lyrics: "", cover: null, favorite: false, durationSec: 0, createdAt: Date.now(), hasLocalAudio: true };
    });
    setSongs((prev) => [...prev, ...newSongs]);
  };

  const registerHistory = (song) => setHistory((h) => [...h, { id: uid(), songId: song.id, title: song.title, artist: song.artist, key: transposeKey(song.originalKey, song.semitoneOffset || 0), bpm: song.bpm, ts: Date.now() }]);

  const openSongForPlay = async (song) => {
    setActiveSong(song); setActiveSetlist(null); setScreen("player");
    const url = audioUrlMap.current[song.id];
    if (!url) { engine.cleanup(); return; }
    await engine.load(url, 1, song.semitoneOffset || 0);
    registerHistory(song);
  };
  const playSetlistAt = async (setlist, index) => {
    const song = songs.find((s) => s.id === setlist.songIds[index]);
    if (!song) return;
    setActiveSetlist({ setlist, index }); setActiveSong(song); setScreen("player");
    const url = audioUrlMap.current[song.id];
    if (url) await engine.load(url, 1, song.semitoneOffset || 0);
    registerHistory(song);
  };
  const goNext = () => { if (!activeSetlist) return; const { setlist, index } = activeSetlist; if (index + 1 < setlist.songIds.length) playSetlistAt(setlist, index + 1); };
  const goPrev = () => { if (!activeSetlist) return; const { setlist, index } = activeSetlist; if (index - 1 >= 0) playSetlistAt(setlist, index - 1); };

  const updateSong = (updated) => setSongs((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
  const deleteSong = (id) => { setSongs((prev) => prev.filter((s) => s.id !== id)); setScreen("library"); };

  const startShow = () => { if (!setlists.length) return; setShowMode(true); playSetlistAt(setlists[setlists.length - 1], 0); };
  const openVoiceTab = (tab) => { setVoiceTab(tab); setScreen("voice"); };

  useEffect(() => {
    if (!showMode) return;
    let wakeLock;
    (async () => { try { wakeLock = await navigator.wakeLock?.request("screen"); } catch {} })();
    return () => { try { wakeLock?.release(); } catch {} };
  }, [showMode]);

  const nextSongName = useMemo(() => {
    if (!activeSetlist) return null;
    const { setlist, index } = activeSetlist;
    return songs.find((s) => s.id === setlist.songIds[index + 1])?.title || null;
  }, [activeSetlist, songs]);

  const clearAll = async () => {
    if (!confirm("Apagar todos os dados salvos (músicas, setlists, histórico)?")) return;
    setSongs([]); setSetlists([]); setHistory([]);
    await storageSet(K_SONGS, []); await storageSet(K_SETLISTS, []); await storageSet(K_HISTORY, []);
  };

  const handleMidiAction = useCallback((action) => {
    if (action === "next") goNext();
    else if (action === "prev") goPrev();
    else if (action === "playpause") { engine.isPlaying ? engine.pause() : engine.play(); }
  }, [goNext, goPrev, engine]); // eslint-disable-line

  const handleMidiCapture = useCallback((key) => { setPendingMidiKey(key); setCapturingMidi(false); }, []);
  const midi = useMIDIPedals(handleMidiAction, midiMapping, capturingMidi, handleMidiCapture);
  const assignMidiAction = (action) => { setMidiMapping((m) => ({ ...m, [pendingMidiKey]: action })); setPendingMidiKey(null); };

  const generateReport = (data) => { setReportData(data); setTimeout(() => window.print(), 150); };

  return (
    <div className="bg-black min-h-screen font-sans app-shell" style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>
      <style>{`
        .no-scrollbar::-webkit-scrollbar{display:none}
        .print-report{display:none}
        @media print { .app-shell{display:none !important;} .print-report{display:block !important;} }
      `}</style>

      {screen === "home" && <HomeScreen songs={songs} setlists={setlists} onStartShow={startShow} setScreen={setScreen} history={history} openVoiceTab={openVoiceTab} />}

      {screen === "library" && !editingSong && <LibraryScreen songs={songs} setSongs={setSongs} onOpenSong={(s) => setEditingSong(s)} onImport={importFiles} />}
      {screen === "library" && editingSong && <SongEditScreen song={editingSong} onBack={() => setEditingSong(null)} onSave={(f) => { updateSong(f); setEditingSong(null); }} onDelete={(id) => { deleteSong(id); setEditingSong(null); }} />}

      {screen === "setlists" && !openSetlist && <SetlistsScreen setlists={setlists} setSetlists={setSetlists} songs={songs} onOpenSetlist={setOpenSetlist} />}
      {screen === "setlists" && openSetlist && <SetlistDetailScreen setlist={setlists.find((s) => s.id === openSetlist.id) || openSetlist} setSetlists={setSetlists} songs={songs} onBack={() => setOpenSetlist(null)} onPlay={(sl, idx) => playSetlistAt(sl, idx)} />}

      {screen === "voice" && <VoiceScreen songs={songs} updateSong={updateSong} onGenerateReport={generateReport} initialTab={voiceTab} />}

      {screen === "settings" && !showStats && (
        <>
          <SettingsScreen onClearAll={clearAll} midi={midi} mapping={midiMapping} capturing={capturingMidi} setCapturing={setCapturingMidi} pendingKey={pendingMidiKey} assignAction={assignMidiAction} />
          <div className="px-4 -mt-24 mb-4">
            <button onClick={() => setShowStats(true)} className="flex items-center gap-2 bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-white font-semibold text-sm w-full"><BarChart3 size={16} className="text-red-500" /> Ver histórico e estatísticas</button>
          </div>
        </>
      )}
      {screen === "settings" && showStats && <StatsScreen history={history} onBack={() => setShowStats(false)} />}

      {screen === "player" && activeSong && (
        <PlayerScreen song={activeSong} engine={engine} onBack={() => setScreen(activeSetlist ? "setlists" : "library")} onNext={goNext} onPrev={goPrev}
          autoNext={autoNext} setAutoNext={setAutoNext} repeat={repeat} setRepeat={setRepeat}
          onUpdateSong={(s) => { updateSong(s); setActiveSong(s); }} showMode={showMode} onExitShow={() => setShowMode(false)} nextSongName={nextSongName} />
      )}

      <NavBar screen={screen} setScreen={(s) => { setEditingSong(null); setOpenSetlist(null); setShowStats(false); setScreen(s); }} hidden={showMode} />
      <PrintReport data={reportData} />
    </div>
  );
}
