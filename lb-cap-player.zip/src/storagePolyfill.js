/**
 * Polyfill for the window.storage API used inside Claude Artifacts,
 * backed by the browser's localStorage so the app works standalone.
 */
if (typeof window !== "undefined" && !window.storage) {
  const PREFIX = "lb-cap-player:";

  window.storage = {
    async get(key) {
      try {
        const raw = localStorage.getItem(PREFIX + key);
        if (raw === null) return null;
        return { key, value: raw };
      } catch (e) {
        console.error("storage.get error", e);
        return null;
      }
    },
    async set(key, value) {
      try {
        localStorage.setItem(PREFIX + key, value);
        return { key, value };
      } catch (e) {
        console.error("storage.set error", e);
        return null;
      }
    },
    async delete(key) {
      try {
        localStorage.removeItem(PREFIX + key);
        return { key, deleted: true };
      } catch (e) {
        console.error("storage.delete error", e);
        return null;
      }
    },
    async list(prefix = "") {
      try {
        const keys = [];
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.startsWith(PREFIX + prefix)) keys.push(k.slice(PREFIX.length));
        }
        return { keys, prefix };
      } catch (e) {
        console.error("storage.list error", e);
        return null;
      }
    },
  };
}
