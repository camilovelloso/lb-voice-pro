# LB CAP Player

App de player para voz e violão: setlists, transposição de tom, detecção de afinação/acordes e histórico.

## Como abrir o projeto localmente

Pré-requisito: [Node.js](https://nodejs.org) instalado (versão 18 ou superior).

```bash
# 1. Instalar as dependências
npm install

# 2. Rodar em modo desenvolvimento
npm run dev
```

Depois abra o endereço mostrado no terminal (normalmente `http://localhost:5173`).

## Como gerar a versão de produção

```bash
npm run build
```

Isso cria a pasta `dist/` com os arquivos finais, prontos para publicar em qualquer hospedagem estática (Vercel, Netlify, GitHub Pages, etc).

Para testar a versão de produção localmente:

```bash
npm run preview
```

## Subir para o GitHub

```bash
git init
git add .
git commit -m "Initial commit - LB CAP Player"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

## Publicar gratuitamente (opcional)

- **Vercel**: importe o repositório em vercel.com, ele detecta o Vite automaticamente.
- **Netlify**: importe o repositório, comando de build `npm run build`, pasta de saída `dist`.
- **GitHub Pages**: use a action `vitejs/vite` ou o pacote `gh-pages` para publicar a pasta `dist`.

## Observações técnicas

- Os dados (músicas, setlists, histórico) são salvos no `localStorage` do navegador, então
  ficam apenas no dispositivo/navegador usado — não há sincronização entre aparelhos.
- Áudio processado com [Tone.js](https://tonejs.github.io/).
- Ícones via [lucide-react](https://lucide.dev/).
- Estilo com Tailwind CSS.
